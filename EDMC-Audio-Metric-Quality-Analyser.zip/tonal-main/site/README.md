# tonal docs

Run development server:

```bash
pnpm dev
```
