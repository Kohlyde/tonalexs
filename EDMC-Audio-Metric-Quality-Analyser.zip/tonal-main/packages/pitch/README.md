# @tonaljs/pitch ![tonal](https://img.shields.io/badge/@tonaljs-pitch-yellow.svg?style=flat-square) [![npm version](https://img.shields.io/npm/v/@tonaljs/pitch.svg?style=flat-square)](https://www.npmjs.com/package/@tonaljs/pitch)

> A notation agnostic representation of pitch

## Usage

You probably don't need this package: is only required if you're planning to add support for more pitch notations.
