# @tonaljs/pitch

## 5.0.2

### Patch Changes

- 48fecc4: Improve `isPitch` detection to accept `NaN` as values.

## 5.0.1

### Patch Changes

- Named type was renamed to NamedPitch. Add old export for backwards compatibility

## 5.0.0

First release
