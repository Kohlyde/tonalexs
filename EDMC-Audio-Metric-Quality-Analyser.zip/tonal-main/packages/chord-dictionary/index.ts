export * from "@tonaljs/chord-type";
export { default } from "@tonaljs/chord-type";
