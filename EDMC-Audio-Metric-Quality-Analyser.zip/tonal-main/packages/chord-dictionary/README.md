# Deprecated. Use [@tonaljs/chord-type](https://github.com/tonaljs/tonal/tree/master/packages/chord-type)
