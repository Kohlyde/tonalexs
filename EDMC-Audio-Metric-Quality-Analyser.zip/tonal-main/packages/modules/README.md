# Deprecated

## Use: [tonal](/packages/tonal)
