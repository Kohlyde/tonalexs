# deprecated: @tonaljs/array

Renamed to [`@tonaljs/collection`](/packages/collection)
