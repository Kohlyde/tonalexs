# Deprecated. Use [@tonaljs/scale-type](https://github.com/tonaljs/tonal/tree/master/packages/scale-type)
