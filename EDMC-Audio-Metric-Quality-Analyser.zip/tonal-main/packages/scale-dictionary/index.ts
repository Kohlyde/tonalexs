export * from "@tonaljs/scale-type";
export { default } from "@tonaljs/scale-type";
